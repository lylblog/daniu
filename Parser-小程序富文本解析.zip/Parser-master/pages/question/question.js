// miniprogram/pages/question/question.js
Page({
  data: {
    code: [{
      "children": [{
        "text": "tagStyle:{",
        "type": "text"
      }, {
        "children": [],
        "name": "br",
        "attrs": {
          "style": ";"
        }
      }, {
        "text": "  ",
        "type": "text"
      }, {
        "children": [{
          "text": "table",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #a71d5d;\n;"
        }
      }, {
        "text": ":",
        "type": "text"
      }, {
        "children": [{
          "text": "\"border-collapse:collapse;border-top:1px solid gray;border-left:1px solid gray;\"",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #df5000;\n;"
        }
      }, {
        "text": ",",
        "type": "text"
      }, {
        "children": [],
        "name": "br",
        "attrs": {
          "style": ";"
        }
      }, {
        "text": "  ",
        "type": "text"
      }, {
        "children": [{
          "text": "th",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #a71d5d;\n;"
        }
      }, {
        "text": ":",
        "type": "text"
      }, {
        "children": [{
          "text": "\"border-right:1px solid gray;border-bottom:1px solid gray;\"",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #df5000;\n;"
        }
      }, {
        "text": ",",
        "type": "text"
      }, {
        "children": [],
        "name": "br",
        "attrs": {
          "style": ";"
        }
      }, {
        "text": "  ",
        "type": "text"
      }, {
        "children": [{
          "text": "td",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #a71d5d;\n;"
        }
      }, {
        "text": ":",
        "type": "text"
      }, {
        "children": [{
          "text": "\"border-right:1px solid gray;border-bottom:1px solid gray;\"",
          "type": "text"
        }],
        "name": "span",
        "attrs": {
          "style": ";\n  color: #df5000;\n;"
        }
      }, {
        "children": [],
        "name": "br",
        "attrs": {
          "style": ";"
        }
      }, {
        "text": "}",
        "type": "text"
      }],
      "name": "div",
      "attrs": {
        "style": ";font-family:monospace;white-space:pre;overflow:scroll;\n  display: block;\n  background: white;\n  padding: 0.5em;\n  color: #333333;\n  overflow-x: auto;\n;"
      }
    }]
  }
})